import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CarListing, 
  ViewMode 
} from '../types';
import { 
  ArrowLeft, 
  DollarSign, 
  Sparkles, 
  Calendar, 
  MapPin, 
  Phone, 
  Star, 
  Fuel, 
  TrendingDown, 
  Gauge, 
  ShieldAlert, 
  TrendingUp, 
  Cpu, 
  Activity, 
  User, 
  Sliders, 
  Award,
  Info,
  CheckCircle,
  Clock
} from 'lucide-react';

interface CarDetailsProps {
  car: CarListing;
  onBack: () => void;
  onToggleCompare: () => void;
  isSaved: boolean;
}

export default function CarDetails({
  car,
  onBack,
  onToggleCompare,
  isSaved,
}: CarDetailsProps) {
  // Dual layout mode (Standard Price vs True Owning Cost)
  const [detailViewMode, setDetailViewMode] = useState<ViewMode>('standard');

  // Simulator State Variables (The core interactive feature missing from other sites)
  const [downpayment, setDownpayment] = useState<number>(Math.round(car.price * 0.20));
  const [interestRate, setInterestRate] = useState<number>(5.9);
  const [loanTerm, setLoanTerm] = useState<number>(5); // years
  const [monthlyMileage, setMonthlyMileage] = useState<number>(1500); // km
  const [fuelCostInput, setFuelCostInput] = useState<number>(
    car.specs.fuelType === 'electric' ? 0.18 : 1.65
  );
  const [driverProfile, setDriverProfile] = useState<'youth' | 'standard' | 'veteran'>('standard');
  const [usageIntensity, setUsageIntensity] = useState<'gentle' | 'standard' | 'sport'>('standard');

  // Real-time calculations using formal financial formulas
  const loanPaymentCalculated = useMemo(() => {
    const principal = car.price - downpayment;
    if (principal <= 0) return 0;
    
    const monthlyRate = (interestRate / 100) / 12;
    const totalPayments = loanTerm * 12;
    
    if (monthlyRate === 0) {
      return principal / totalPayments;
    }
    
    const pmt = (principal * monthlyRate * Math.pow(1 + monthlyRate, totalPayments)) / 
                (Math.pow(1 + monthlyRate, totalPayments) - 1);
    
    return Math.round(pmt);
  }, [car.price, downpayment, interestRate, loanTerm]);

  // Real-time Energy/Fuel Cost calculation
  const energyCostCalculated = useMemo(() => {
    // electric efficiency is kWh/100km, fuel efficiency is L/100km
    return Math.round((monthlyMileage * car.specs.fuelEfficiency * fuelCostInput) / 100);
  }, [monthlyMileage, car.specs.fuelEfficiency, fuelCostInput]);

  // Real-time Insurance cost depending on profile
  const insuranceCalculated = useMemo(() => {
    const base = car.expenses.insurance;
    if (driverProfile === 'youth') return Math.round(base * 1.75);
    if (driverProfile === 'veteran') return Math.round(base * 0.82);
    return base;
  }, [car.expenses.insurance, driverProfile]);

  // Real-time Repairs & Maintenance depending on usage intensity
  const repairsCalculated = useMemo(() => {
    const base = car.expenses.repairs;
    if (usageIntensity === 'gentle') return Math.round(base * 0.70);
    if (usageIntensity === 'sport') return Math.round(base * 1.45);
    return base;
  }, [car.expenses.repairs, usageIntensity]);

  // Base depreciation (remains linear estimate for simple projection)
  const depreciationCalculated = car.expenses.depreciation;

  // Aggregate Total Monthly Expense
  const totalMonthlyTCO = useMemo(() => {
    return loanPaymentCalculated + energyCostCalculated + insuranceCalculated + repairsCalculated + depreciationCalculated;
  }, [loanPaymentCalculated, energyCostCalculated, insuranceCalculated, repairsCalculated, depreciationCalculated]);

  // 1-Year, 3-Year, 5-Year Cumulative Expenses
  const cumulativeCosts = useMemo(() => {
    const monthlyTotal = totalMonthlyTCO;
    return {
      year1: monthlyTotal * 12,
      year3: monthlyTotal * 36,
      year5: monthlyTotal * 60,
    };
  }, [totalMonthlyTCO]);

  // Value depreciation curve projection (gorgeous data visualizer)
  const valueCurvePoints = useMemo(() => {
    const points = [];
    const initialValue = car.price;
    // Estimated depreciation curve
    const deprecationRates = [1, 0.82, 0.70, 0.61, 0.54, 0.48]; // multipliers for year 0, 1, 2, 3, 4, 5
    for (let i = 0; i <= 5; i++) {
      points.push({
        year: i,
        value: Math.round(initialValue * deprecationRates[i]),
      });
    }
    return points;
  }, [car.price]);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 transition-colors duration-300">
      
      {/* Detail Page Controls */}
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <button
          onClick={onBack}
          className="group flex items-center gap-2 rounded-full border border-neutral-200 bg-white px-4 py-2 text-xs font-bold text-neutral-800 shadow-xs hover:bg-neutral-50 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-200 dark:hover:bg-neutral-800 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
          Back to Inventory
        </button>

        {/* Dynamic Dual View Toggle Button */}
        <div className="flex rounded-full border border-neutral-200 p-1 bg-white shadow-xs dark:border-neutral-800 dark:bg-neutral-900">
          <button
            onClick={() => setDetailViewMode('standard')}
            className={`flex items-center gap-2 rounded-full px-5 py-2 text-xs font-bold transition-all duration-200 cursor-pointer ${
              detailViewMode === 'standard'
                ? 'bg-neutral-950 text-white dark:bg-neutral-100 dark:text-neutral-950 shadow-xs'
                : 'text-neutral-500 hover:text-neutral-800 dark:hover:text-neutral-300'
            }`}
          >
            <DollarSign className="h-4 w-4" />
            Standard Listing Spec
          </button>
          
          <button
            onClick={() => setDetailViewMode('ownership')}
            className={`flex items-center gap-2 rounded-full px-5 py-2 text-xs font-bold transition-all duration-200 cursor-pointer ${
              detailViewMode === 'ownership'
                ? 'bg-emerald-500 text-white shadow-xs'
                : 'text-neutral-500 hover:text-emerald-500'
            }`}
          >
            <Sparkles className="h-4 w-4" />
            Ownership Reality TCO
          </button>
        </div>

        {/* Save button */}
        <button
          onClick={onToggleCompare}
          className={`rounded-full px-5 py-2 text-xs font-bold transition-all duration-200 cursor-pointer ${
            isSaved
              ? 'bg-emerald-500 text-white'
              : 'border border-neutral-200 bg-white text-neutral-800 hover:bg-neutral-50 dark:border-neutral-800 dark:bg-neutral-900 dark:text-neutral-200'
          }`}
        >
          {isSaved ? 'Saved in Compare' : 'Add to Compare Deck'}
        </button>
      </div>

      {/* Main Container Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* Left Column: Media Gallery, General Specs, Character Assessment */}
        <div className="lg:col-span-7 space-y-6">
          {/* Main Photo Card */}
          <div className="overflow-hidden rounded-2xl border border-neutral-200 bg-white p-2 dark:border-neutral-800 dark:bg-neutral-900/60 shadow-xs">
            <div className="relative aspect-16/9 w-full overflow-hidden rounded-xl bg-neutral-100 dark:bg-neutral-800">
              <img
                src={car.image}
                alt={`${car.make} ${car.model}`}
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover"
              />
              <div className="absolute top-4 left-4 rounded-full bg-black/70 backdrop-blur-md px-3 py-1 text-[11px] font-bold text-white uppercase tracking-wider">
                {car.year} Model Year
              </div>
              <div className="absolute top-4 right-4 rounded-full bg-emerald-500/95 backdrop-blur-md px-3 py-1 text-[11px] font-bold text-white shadow-sm">
                Score: {car.truthScore}/100
              </div>
            </div>
          </div>

          {/* Core Specs Grid */}
          <div className="rounded-2xl border border-neutral-200 bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900/60">
            <h3 className="font-sans text-base font-bold tracking-tight text-neutral-900 dark:text-white mb-4 flex items-center gap-2">
              <Cpu className="h-4 w-4 text-neutral-500" />
              Mechanical and Efficiency Parameters
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="rounded-xl bg-neutral-50 p-3.5 dark:bg-neutral-950/40">
                <p className="text-[10px] font-mono font-semibold uppercase text-neutral-400">Powerplant</p>
                <p className="mt-1 font-sans text-sm font-bold text-neutral-800 dark:text-neutral-200">{car.specs.engine}</p>
              </div>
              <div className="rounded-xl bg-neutral-50 p-3.5 dark:bg-neutral-950/40">
                <p className="text-[10px] font-mono font-semibold uppercase text-neutral-400">Total Output</p>
                <p className="mt-1 font-sans text-sm font-bold text-neutral-800 dark:text-neutral-200">{car.specs.power}</p>
              </div>
              <div className="rounded-xl bg-neutral-50 p-3.5 dark:bg-neutral-950/40">
                <p className="text-[10px] font-mono font-semibold uppercase text-neutral-400">0 - 100 km/h</p>
                <p className="mt-1 font-sans text-sm font-bold text-neutral-800 dark:text-neutral-200">{car.specs.acceleration}</p>
              </div>
              <div className="rounded-xl bg-neutral-50 p-3.5 dark:bg-neutral-950/40">
                <p className="text-[10px] font-mono font-semibold uppercase text-neutral-400">Efficiency</p>
                <p className="mt-1 font-sans text-sm font-bold text-neutral-800 dark:text-neutral-200">
                  {car.specs.fuelEfficiency} {car.specs.fuelType === 'electric' ? 'kWh' : 'L'}/100km
                </p>
              </div>
              <div className="rounded-xl bg-neutral-50 p-3.5 dark:bg-neutral-950/40">
                <p className="text-[10px] font-mono font-semibold uppercase text-neutral-400">Transmission</p>
                <p className="mt-1 font-sans text-sm font-bold text-neutral-800 dark:text-neutral-200">{car.specs.transmission}</p>
              </div>
              <div className="rounded-xl bg-neutral-50 p-3.5 dark:bg-neutral-950/40">
                <p className="text-[10px] font-mono font-semibold uppercase text-neutral-400">Drivetrain</p>
                <p className="mt-1 font-sans text-sm font-bold text-neutral-800 dark:text-neutral-200">{car.specs.driveType}</p>
              </div>
              <div className="rounded-xl bg-neutral-50 p-3.5 dark:bg-neutral-950/40 col-span-2">
                <p className="text-[10px] font-mono font-semibold uppercase text-neutral-400">Estimated Range</p>
                <p className="mt-1 font-sans text-sm font-bold text-neutral-800 dark:text-neutral-200">
                  {car.specs.range || 'Approximately 750+ km dynamic range'}
                </p>
              </div>
            </div>
          </div>

          {/* Emotional Component: Genuine Driver Insight */}
          <div className="rounded-2xl border border-neutral-200 bg-neutral-900 text-white p-6 dark:bg-neutral-950/40">
            <h3 className="font-sans text-base font-bold tracking-tight text-white mb-3 flex items-center gap-2">
              <Award className="h-4 w-4 text-amber-400" />
              The Driver Vibe Check
            </h3>
            <blockquote className="italic font-light text-neutral-300 text-sm leading-relaxed">
              &ldquo;{car.ownerReview}&rdquo;
            </blockquote>
            <div className="mt-4 flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="font-mono text-[10px] uppercase font-bold text-neutral-400 tracking-wider">Verified long-term owner perspective</span>
            </div>
          </div>

          {/* Highlights Checklist */}
          <div className="rounded-2xl border border-neutral-200 bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900/60">
            <h3 className="font-sans text-base font-bold tracking-tight text-neutral-900 dark:text-white mb-4">
              Premium Configuration highlights
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {car.highlights.map((h, i) => (
                <div key={i} className="flex items-start gap-2.5 text-sm text-neutral-600 dark:text-neutral-400">
                  <CheckCircle className="h-4.5 w-4.5 text-emerald-500 shrink-0 mt-0.5" />
                  <span>{h}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Dynamic toggled interfaces (Side A standard pricing vs Side B dynamic calculator) */}
        <div className="lg:col-span-5 space-y-6">
          <AnimatePresence mode="wait">
            {detailViewMode === 'standard' ? (
              
              /* ========================================================= */
              /* SIDE A: STANDARD SPEC & LISTING INFO                      */
              /* ========================================================= */
              <motion.div
                key="sideA"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                {/* Standard Price Card */}
                <div className="rounded-2xl border border-neutral-200 bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900/60 shadow-sm">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="text-[10px] font-mono font-bold uppercase tracking-widest text-neutral-400 dark:text-neutral-500">
                        verified selling price
                      </p>
                      <h2 className="font-sans text-3xl font-extrabold tracking-tight text-neutral-900 dark:text-white mt-1">
                        ${car.price.toLocaleString()}
                      </h2>
                    </div>
                    <span className="rounded-full bg-emerald-50 text-emerald-700 px-3 py-1 text-xs font-bold dark:bg-emerald-950/30 dark:text-emerald-400">
                      Standard Title
                    </span>
                  </div>

                  <p className="mt-4 text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
                    This represents the upfront sticker price for a private-sale cash transfer or dealer checkout. Standard title transfer, municipal registration, and environmental road tax estimates total approximately <strong>$1,200</strong> depending on location.
                  </p>

                  <div className="mt-6 space-y-3">
                    <div className="flex justify-between text-xs py-2 border-b border-neutral-100 dark:border-neutral-800">
                      <span className="text-neutral-500">Base Listing Price</span>
                      <span className="font-mono font-bold text-neutral-800 dark:text-neutral-200">${car.price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-xs py-2 border-b border-neutral-100 dark:border-neutral-800">
                      <span className="text-neutral-500">Title & Reg. Est</span>
                      <span className="font-mono font-bold text-neutral-800 dark:text-neutral-200">$450</span>
                    </div>
                    <div className="flex justify-between text-xs py-2 border-b border-neutral-100 dark:border-neutral-800">
                      <span className="text-neutral-500">Dealer Prep / Doc Fees</span>
                      <span className="font-mono font-bold text-neutral-800 dark:text-neutral-200">$295</span>
                    </div>
                    <div className="flex justify-between text-xs py-2">
                      <span className="font-bold text-neutral-900 dark:text-white">Estimated Driveaway Cash</span>
                      <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">${(car.price + 745).toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Seller Bio Card */}
                <div className="rounded-2xl border border-neutral-200 bg-white p-6 dark:border-neutral-800 dark:bg-neutral-900/60">
                  <h3 className="font-sans text-base font-bold tracking-tight text-neutral-900 dark:text-white mb-4">
                    Listing Owner & Location
                  </h3>
                  <div className="flex items-center gap-4">
                    <img
                      src={car.seller.avatar}
                      alt={car.seller.name}
                      referrerPolicy="no-referrer"
                      className="h-12 w-12 rounded-full object-cover border border-neutral-100 shadow-xs"
                    />
                    <div>
                      <h4 className="text-sm font-bold text-neutral-900 dark:text-white">{car.seller.name}</h4>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className="rounded-md bg-neutral-100 px-2 py-0.5 text-[9px] font-mono font-bold uppercase text-neutral-500 dark:bg-neutral-800">
                          {car.seller.type}
                        </span>
                        <div className="flex items-center text-amber-500 text-xs">
                          <Star className="h-3.5 w-3.5 fill-current" />
                          <span className="ml-1 font-bold">{car.seller.rating}</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-6 space-y-3 text-xs">
                    <div className="flex items-center gap-2.5 text-neutral-600 dark:text-neutral-400">
                      <MapPin className="h-4.5 w-4.5 text-neutral-400" />
                      <span>{car.seller.location} &bull; Remote purchase available</span>
                    </div>
                    <div className="flex items-center gap-2.5 text-neutral-600 dark:text-neutral-400">
                      <Phone className="h-4.5 w-4.5 text-neutral-400" />
                      <span>{car.seller.phone} &bull; Call or encrypted text</span>
                    </div>
                    <div className="flex items-center gap-2.5 text-neutral-600 dark:text-neutral-400">
                      <Clock className="h-4.5 w-4.5 text-neutral-400" />
                      <span>Listed 2 days ago &bull; 1,440 views</span>
                    </div>
                  </div>

                  <div className="mt-6 pt-2">
                    <button 
                      onClick={() => alert(`Connecting securely with ${car.seller.name}. Phone: ${car.seller.phone}`)}
                      className="w-full rounded-xl bg-neutral-950 py-3 text-xs font-bold text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 cursor-pointer text-center"
                    >
                      Contact Owner Securly
                    </button>
                  </div>
                </div>

                {/* autod.pro Smart Truth Check Breakdown */}
                <div className="rounded-2xl border border-neutral-200 bg-emerald-500/10 p-6 dark:border-emerald-500/20 dark:bg-emerald-950/10">
                  <div className="flex gap-3">
                    <CheckCircle className="h-6 w-6 text-emerald-500 shrink-0" />
                    <div>
                      <h4 className="font-sans text-sm font-bold text-neutral-900 dark:text-white">Why the autod.pro score is {car.truthScore}</h4>
                      <p className="mt-1 text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
                        No typical classified platform calculates value honesty. This listing scores exceptionally high due to the following metrics compiled from our decentralized registry:
                      </p>
                      
                      <div className="mt-4 space-y-2.5">
                        <div>
                          <div className="flex justify-between text-[11px] font-mono text-neutral-500 mb-1">
                            <span>Value Retention Rate</span>
                            <span className="font-bold text-neutral-800 dark:text-neutral-200">{car.truthBreakdown.valueRetention}%</span>
                          </div>
                          <div className="h-1 w-full bg-neutral-200 dark:bg-neutral-800 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${car.truthBreakdown.valueRetention}%` }} />
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-[11px] font-mono text-neutral-500 mb-1">
                            <span>Predicted Reliability Index</span>
                            <span className="font-bold text-neutral-800 dark:text-neutral-200">{car.truthBreakdown.reliability}%</span>
                          </div>
                          <div className="h-1 w-full bg-neutral-200 dark:bg-neutral-800 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${car.truthBreakdown.reliability}%` }} />
                          </div>
                        </div>

                        <div>
                          <div className="flex justify-between text-[11px] font-mono text-neutral-500 mb-1">
                            <span>Running Cost Optimization</span>
                            <span className="font-bold text-neutral-800 dark:text-neutral-200">{car.truthBreakdown.runningCosts}%</span>
                          </div>
                          <div className="h-1 w-full bg-neutral-200 dark:bg-neutral-800 rounded-full overflow-hidden">
                            <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${car.truthBreakdown.runningCosts}%` }} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ) : (
              
              /* ========================================================= */
              /* SIDE B: INTERACTIVE OWNERSHIP SIMULATOR (TCO)             */
              /* ========================================================= */
              <motion.div
                key="sideB"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                {/* Simulated TCO Total Card */}
                <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-6 dark:border-emerald-500/30 dark:bg-emerald-950/5">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-1">
                        <p className="text-[10px] font-mono font-bold tracking-widest text-emerald-600 dark:text-emerald-400 uppercase">
                          simulated dynamic tco
                        </p>
                        <Sparkles className="h-3.5 w-3.5 text-emerald-500 animate-pulse" />
                      </div>
                      <h2 className="font-mono text-3xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                        ${totalMonthlyTCO.toLocaleString()}<span className="text-sm font-normal text-neutral-400"> / mo</span>
                      </h2>
                    </div>
                    <div className="text-right">
                      <p className="text-[10px] font-mono font-bold tracking-widest text-neutral-400 uppercase">
                        yearly impact
                      </p>
                      <p className="font-mono text-lg font-bold text-neutral-700 dark:text-neutral-300">
                        ${(totalMonthlyTCO * 12).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  {/* Expense segment ratios */}
                  <div className="h-2.5 w-full flex overflow-hidden rounded-full bg-neutral-200 dark:bg-neutral-800 mt-5">
                    <div className="bg-neutral-900 dark:bg-white" style={{ width: `${(loanPaymentCalculated / totalMonthlyTCO) * 100}%` }} title="Finance" />
                    <div className="bg-emerald-500" style={{ width: `${(energyCostCalculated / totalMonthlyTCO) * 100}%` }} title="Energy" />
                    <div className="bg-amber-500" style={{ width: `${(repairsCalculated / totalMonthlyTCO) * 100}%` }} title="Maintenance" />
                    <div className="bg-sky-500" style={{ width: `${(insuranceCalculated / totalMonthlyTCO) * 100}%` }} title="Insurance" />
                    <div className="bg-rose-500" style={{ width: `${(depreciationCalculated / totalMonthlyTCO) * 100}%` }} title="Depreciation" />
                  </div>
                  
                  {/* Legend Grid */}
                  <div className="grid grid-cols-5 gap-1.5 pt-3 text-[9px] font-mono font-bold text-neutral-400 uppercase">
                    <div className="flex flex-col">
                      <span className="flex items-center gap-1 text-neutral-700 dark:text-neutral-300">
                        <span className="h-2 w-2 rounded-full bg-neutral-900 dark:bg-white inline-block" />
                        Loan
                      </span>
                      <span className="text-[11px] font-semibold text-neutral-800 dark:text-neutral-100 mt-0.5">${loanPaymentCalculated}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400">
                        <span className="h-2 w-2 rounded-full bg-emerald-500 inline-block" />
                        Energy
                      </span>
                      <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 mt-0.5">${energyCostCalculated}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="flex items-center gap-1 text-amber-500">
                        <span className="h-2 w-2 rounded-full bg-amber-500 inline-block" />
                        Mnt
                      </span>
                      <span className="text-[11px] font-semibold text-neutral-800 dark:text-neutral-100 mt-0.5">${repairsCalculated}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="flex items-center gap-1 text-sky-500">
                        <span className="h-2 w-2 rounded-full bg-sky-500 inline-block" />
                        Insur
                      </span>
                      <span className="text-[11px] font-semibold text-neutral-800 dark:text-neutral-100 mt-0.5">${insuranceCalculated}</span>
                    </div>
                    <div className="flex flex-col">
                      <span className="flex items-center gap-1 text-rose-500">
                        <span className="h-2 w-2 rounded-full bg-rose-500 inline-block" />
                        Depr
                      </span>
                      <span className="text-[11px] font-semibold text-neutral-800 dark:text-neutral-100 mt-0.5">${depreciationCalculated}</span>
                    </div>
                  </div>
                </div>

                {/* Interactive Sliders Bento Grid */}
                <div className="rounded-2xl border border-neutral-200 bg-white p-5 dark:border-neutral-800 dark:bg-neutral-900/60 space-y-6">
                  
                  {/* SLIDER 1: FINANCING TERMS */}
                  <div className="space-y-4">
                    <div className="flex items-center gap-1.5 border-b border-neutral-100 dark:border-neutral-800 pb-2">
                      <Sliders className="h-4 w-4 text-neutral-500" />
                      <h4 className="text-xs font-bold text-neutral-900 uppercase dark:text-white">Financing parameters</h4>
                    </div>

                    {/* Downpayment */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-neutral-500">Downpayment Cash</span>
                        <span className="font-mono font-bold">${downpayment.toLocaleString()} ({Math.round((downpayment / car.price) * 100)}%)</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max={Math.round(car.price * 0.80)}
                        step="500"
                        value={downpayment}
                        onChange={(e) => setDownpayment(Number(e.target.value))}
                        className="w-full accent-neutral-950 dark:accent-white h-1.5 rounded-lg bg-neutral-200 dark:bg-neutral-700 appearance-none"
                      />
                    </div>

                    {/* Interest Rate & Term Grid */}
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs">
                          <span className="text-neutral-500">Interest Rate</span>
                          <span className="font-mono font-bold">{interestRate}%</span>
                        </div>
                        <input
                          type="range"
                          min="1"
                          max="15"
                          step="0.1"
                          value={interestRate}
                          onChange={(e) => setInterestRate(Number(e.target.value))}
                          className="w-full accent-neutral-950 dark:accent-white h-1.5 rounded-lg bg-neutral-200 dark:bg-neutral-700 appearance-none"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <div className="flex justify-between text-xs">
                          <span className="text-neutral-500">Loan Duration</span>
                          <span className="font-mono font-bold">{loanTerm} Years</span>
                        </div>
                        <input
                          type="range"
                          min="1"
                          max="7"
                          step="1"
                          value={loanTerm}
                          onChange={(e) => setLoanTerm(Number(e.target.value))}
                          className="w-full accent-neutral-950 dark:accent-white h-1.5 rounded-lg bg-neutral-200 dark:bg-neutral-700 appearance-none"
                        />
                      </div>
                    </div>
                  </div>

                  {/* SLIDER 2: MILEAGE & UTILITY */}
                  <div className="space-y-4 pt-2">
                    <div className="flex items-center gap-1.5 border-b border-neutral-100 dark:border-neutral-800 pb-2">
                      <Fuel className="h-4 w-4 text-emerald-500" />
                      <h4 className="text-xs font-bold text-neutral-900 uppercase dark:text-white">energy & mileage dynamics</h4>
                    </div>

                    {/* Monthly Mileage */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-neutral-500">Monthly Mileage Goal</span>
                        <span className="font-mono font-bold text-emerald-500">{monthlyMileage.toLocaleString()} km / month</span>
                      </div>
                      <input
                        type="range"
                        min="500"
                        max="4000"
                        step="100"
                        value={monthlyMileage}
                        onChange={(e) => setMonthlyMileage(Number(e.target.value))}
                        className="w-full accent-emerald-500 h-1.5 rounded-lg bg-neutral-200 dark:bg-neutral-700 appearance-none"
                      />
                    </div>

                    {/* Cost per Liter/kWh */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-xs">
                        <span className="text-neutral-500">
                          Local {car.specs.fuelType === 'electric' ? 'Electricity Cost ($/kWh)' : 'Fuel Cost ($/L)'}
                        </span>
                        <span className="font-mono font-bold">${fuelCostInput}</span>
                      </div>
                      <input
                        type="range"
                        min={car.specs.fuelType === 'electric' ? '0.05' : '1.00'}
                        max={car.specs.fuelType === 'electric' ? '0.50' : '2.50'}
                        step="0.01"
                        value={fuelCostInput}
                        onChange={(e) => setFuelCostInput(Number(e.target.value))}
                        className="w-full accent-emerald-500 h-1.5 rounded-lg bg-neutral-200 dark:bg-neutral-700 appearance-none"
                      />
                    </div>
                  </div>

                  {/* PROFILE CONTROLS: INSURANCE & USAGE INTENSITY */}
                  <div className="space-y-4 pt-2">
                    <div className="flex items-center gap-1.5 border-b border-neutral-100 dark:border-neutral-800 pb-2">
                      <User className="h-4 w-4 text-sky-500" />
                      <h4 className="text-xs font-bold text-neutral-900 uppercase dark:text-white">risk & usage categories</h4>
                    </div>

                    {/* Driver age profile for insurance */}
                    <div className="space-y-1.5">
                      <p className="text-xs text-neutral-500">Insurance Driver Class</p>
                      <div className="grid grid-cols-3 gap-2">
                        {(['youth', 'standard', 'veteran'] as const).map((profile) => (
                          <button
                            key={profile}
                            onClick={() => setDriverProfile(profile)}
                            className={`rounded-lg py-1.5 text-xs font-bold transition-all ${
                              driverProfile === profile
                                ? 'bg-sky-500 text-white shadow-xs'
                                : 'bg-neutral-50 text-neutral-600 hover:bg-neutral-100 dark:bg-neutral-950 dark:text-neutral-400 dark:hover:bg-neutral-800'
                            }`}
                          >
                            {profile === 'youth' ? 'Under 25' : profile === 'standard' ? '25-50 yrs' : '50+ Veteran'}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Driving Style for maintenance wear */}
                    <div className="space-y-1.5">
                      <p className="text-xs text-neutral-500">Driving Style (Maintenance Multiplier)</p>
                      <div className="grid grid-cols-3 gap-2">
                        {(['gentle', 'standard', 'sport'] as const).map((style) => (
                          <button
                            key={style}
                            onClick={() => setUsageIntensity(style)}
                            className={`rounded-lg py-1.5 text-xs font-bold transition-all ${
                              usageIntensity === style
                                ? 'bg-amber-500 text-white shadow-xs'
                                : 'bg-neutral-50 text-neutral-600 hover:bg-neutral-100 dark:bg-neutral-950 dark:text-neutral-400 dark:hover:bg-neutral-800'
                            }`}
                          >
                            {style === 'gentle' ? 'Gentle Eco' : style === 'standard' ? 'Standard' : 'Aggressive'}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                </div>

                {/* 5-Year Depreciation Trend Custom Chart */}
                <div className="rounded-2xl border border-neutral-200 bg-white p-5 dark:border-neutral-800 dark:bg-neutral-900/60">
                  <h4 className="text-xs font-bold text-neutral-900 uppercase dark:text-white mb-1 flex items-center gap-1.5">
                    <TrendingDown className="h-4 w-4 text-rose-500" />
                    5-Year Future Valuation Curve
                  </h4>
                  <p className="text-[11px] text-neutral-400 mb-4">Predicted residual asset worth over 60 months</p>
                  
                  {/* Custom SVG Line Chart */}
                  <div className="h-40 w-full relative">
                    <svg className="w-full h-full" viewBox="0 0 500 150" preserveAspectRatio="none">
                      <defs>
                        <linearGradient id="chartGlow" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#ef4444" stopOpacity="0.25"/>
                          <stop offset="100%" stopColor="#ef4444" stopOpacity="0.0"/>
                        </linearGradient>
                      </defs>
                      {/* Grid lines */}
                      <line x1="0" y1="30" x2="500" y2="30" stroke="#f1f5f9" strokeWidth="1" className="dark:stroke-neutral-800" />
                      <line x1="0" y1="75" x2="500" y2="75" stroke="#f1f5f9" strokeWidth="1" className="dark:stroke-neutral-800" />
                      <line x1="0" y1="120" x2="500" y2="120" stroke="#f1f5f9" strokeWidth="1" className="dark:stroke-neutral-800" />
                      
                      {/* Filled Glow */}
                      <path
                        d={`M 10 20 L 100 45 L 200 65 L 300 85 L 400 95 L 490 105 L 490 140 L 10 140 Z`}
                        fill="url(#chartGlow)"
                      />
                      
                      {/* Main Line */}
                      <path
                        d={`M 10 20 Q 100 45, 200 65 T 300 85 T 400 95 T 490 105`}
                        fill="none"
                        stroke="#ef4444"
                        strokeWidth="3.5"
                        strokeLinecap="round"
                      />
                      
                      {/* Data Dots */}
                      <circle cx="10" cy="20" r="5" fill="#ef4444" stroke="#ffffff" strokeWidth="2" />
                      <circle cx="100" cy="45" r="4" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
                      <circle cx="200" cy="65" r="4" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
                      <circle cx="300" cy="85" r="4" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
                      <circle cx="400" cy="95" r="4" fill="#ef4444" stroke="#ffffff" strokeWidth="1.5" />
                      <circle cx="490" cy="105" r="5" fill="#ef4444" stroke="#ffffff" strokeWidth="2" />
                    </svg>
                    
                    {/* Year Labels under Chart */}
                    <div className="flex justify-between px-2 pt-1.5 text-[9px] font-mono text-neutral-400 font-bold uppercase">
                      <span>Now (${car.price.toLocaleString()})</span>
                      <span>Yr 1 (${valueCurvePoints[1].value.toLocaleString()})</span>
                      <span>Yr 2 (${valueCurvePoints[2].value.toLocaleString()})</span>
                      <span>Yr 3 (${valueCurvePoints[3].value.toLocaleString()})</span>
                      <span>Yr 4 (${valueCurvePoints[4].value.toLocaleString()})</span>
                      <span>Yr 5 (${valueCurvePoints[5].value.toLocaleString()})</span>
                    </div>
                  </div>
                  
                  <div className="mt-4 flex items-start gap-2 rounded-xl bg-rose-500/10 p-3 text-xs text-rose-700 dark:text-rose-400">
                    <Info className="h-4 w-4 shrink-0 mt-0.5" />
                    <span>
                      <strong>Asset Depreciation warning:</strong> This vehicle will shed approximately <strong>${depreciationCalculated} per month</strong> of trade-in value based on mileage and current auction indices. Keep this in mind during cumulative accounting.
                    </span>
                  </div>
                </div>

                {/* Cumulative Expense Milestones */}
                <div className="rounded-2xl border border-neutral-200 bg-white p-5 dark:border-neutral-800 dark:bg-neutral-900/60">
                  <h4 className="text-xs font-bold text-neutral-900 uppercase dark:text-white mb-4">
                    Cumulative Investment Milestones
                  </h4>
                  <div className="space-y-3.5">
                    <div>
                      <div className="flex justify-between text-xs font-semibold text-neutral-600 mb-1 dark:text-neutral-300">
                        <span>1 Year Total Investment</span>
                        <span className="font-mono font-bold text-neutral-900 dark:text-white">${cumulativeCosts.year1.toLocaleString()}</span>
                      </div>
                      <div className="h-1.5 w-full bg-neutral-100 rounded-full dark:bg-neutral-800 overflow-hidden">
                        <div className="h-full bg-emerald-500" style={{ width: '20%' }} />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold text-neutral-600 mb-1 dark:text-neutral-300">
                        <span>3 Year Total Investment</span>
                        <span className="font-mono font-bold text-neutral-900 dark:text-white">${cumulativeCosts.year3.toLocaleString()}</span>
                      </div>
                      <div className="h-1.5 w-full bg-neutral-100 rounded-full dark:bg-neutral-800 overflow-hidden">
                        <div className="h-full bg-emerald-500" style={{ width: '60%' }} />
                      </div>
                    </div>

                    <div>
                      <div className="flex justify-between text-xs font-semibold text-neutral-600 mb-1 dark:text-neutral-300">
                        <span>5 Year Total Investment</span>
                        <span className="font-mono font-bold text-neutral-900 dark:text-white">${cumulativeCosts.year5.toLocaleString()}</span>
                      </div>
                      <div className="h-1.5 w-full bg-neutral-100 rounded-full dark:bg-neutral-800 overflow-hidden">
                        <div className="h-full bg-emerald-500" style={{ width: '100%' }} />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>

    </div>
  );
}
